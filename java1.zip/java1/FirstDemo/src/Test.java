class Ani
{{
	int a;
	String name;
{
	public void eat()
  {
   System.out.println("Animal Eats");
  }
    public void roam()
   {	
    System.out.println("Animal roams");
   }
	
}
}
  class Feline extends Ani
  {
   public void dat()
  {
	  a = 40;
	  name = "ali";
	  System.out.println(+a);
	  System.out.println(+name);
  }
  
	public void eat()
	{
		System.out.println("Feline category eats everything");
	}
    public void roam()
	{
        System.out.println("Feline roams lonely");
	}
  }
  class Test
{
      public static void main(String [] args)
	  {  
	     Feline  b = new Feline();
		  b.eat();
          b.roam();
		  b.dat();
  	
         Ani a = new Ani();
          a.eat();
          a.roam();
		  
		  
		  
		  
  
}}}