class Date
public static void main(String [] args)
{ 
  int dd, mm, yy;
  
} 
public Date(int d, int m, int y)