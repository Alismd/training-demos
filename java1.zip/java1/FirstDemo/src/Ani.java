import java.util.*;
import java.lang.*;
class Ani
{
	      public static void main(String[] args)
	  {
	     Ani  b = new Feline();
  	
         Ani a = new Ani();
   a.eat();
   a.roam();
   b.eat();
   b.roam();
	
	public void eat()
  {
   System.out.println("Animal Eats");
  }
  
  public void roam()
   {	
System.out.println("Animal roams");
   }
	
}}

class Feline extends Ani
{
	
	public void eat()
	{
		System.out.println("Feline category eats everything");
	}
    public void roam()
	{
        System.out.println("Feline roams lonely");
	}
  
}

