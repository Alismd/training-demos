package demo.registrationpage;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;



public class RegistrationTest {

	static WebDriver driver;
	private RegistrationPageTest registration;
	
@BeforeClass
public static void setUpDriverEnv(){
  System.setProperty("webdriver.chrome.driver", "D:\\Users\\mohshaik\\Desktop\\chromedriver\\chromedriver.exe");
  driver= new ChromeDriver();
  driver.manage().window().maximize();
}
@Before
public void setUpTestEnv() {
	driver.get("https://github.com/join?source=header-home");
	registration = new RegistrationPageTest();
	PageFactory.initElements(driver, registration);
}

@Test
public void testForNullUserNamePasswordAndGmail(){	
	registration.setUsername("");
	registration.setEmail("");
	registration.setPassword("");
	registration.clickSubmitButton();
	String actualErrorMessage=driver.findElement(By.xpath("//*[@id='signup-form']/div")).getText();	
	System.out.println("error Message :- "+actualErrorMessage);
	String expectedErrorMessage="There were problems creating your account.";
	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
}
	@Test
public void testForValidUserNameAndPasswordAndGmail(){	
	registration.setUsername("Alismd622221543543");
	registration.setEmail("ali.smd837@gmail.com");
	registration.setPassword("987654321aA");
	registration.clickSubmitButton();
	String actualErrorMessage=driver.findElement(By.xpath("//*[@id='signup-form']")).getText();	
	System.out.println("error Message :- "+actualErrorMessage);
	String expectedErrorMessage="";
	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
}

/*@After
public void tearDownTestEnv(){
	registration= null;
}
@AfterClass
public static void tearDownDriverEnv(){
	driver.close();
	driver=null;
}*/
}
