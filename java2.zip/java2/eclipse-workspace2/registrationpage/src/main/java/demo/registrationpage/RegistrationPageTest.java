package demo.registrationpage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPageTest {
@FindBy(id="user_login")
WebElement username;

@FindBy(id="user_email")
WebElement emailaddress;
	
@FindBy(id="user_password")
WebElement password;

@FindBy(id="signup_button")
WebElement button;


public RegistrationPageTest() {

}
public void setUsername(String username) {
	this.username.sendKeys(username);
}

public WebElement getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password.sendKeys(password);
}
public void setEmail(String emailaddress)
{
	this.emailaddress.sendKeys(emailaddress);
}
public void clickSubmitButton() {
	button.submit();
}
}
