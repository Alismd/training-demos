package demo.githubTest;

import org.openqa.selenium.support.PageFactory;

public class LoginPageTest {
public void setUpTestEnv(){
	driver.get("https://github.com/login");
	loginpage=new LoginPage();
	PageFactory.initElements(driver, loginPage);
}

@Test
public void test+
}
