import java.util.Comparator;
import java.util.TreeSet;



public class Entry {
public static void main(String[] args) {
TreeSet<Product> products =new TreeSet<>(//new ProductComparator()
		);
			
	
	Product product1=new Product(5,"pen",12);
	Product product2=new Product(1,"pencil",4);
	Product product3=new Product(4,"eraser",4);
	Product product4=new Product(12,"sharpner",7);
	Product product5=new Product(105,"headphones",7);
products.add(product1);
products.add(product2);
products.add(product3);
	products.add(product4);
	products.add(product5);
	
	
	
	System.out.println(products.size());
	System.out.println("after sorting");
	for (Product pro: products)
	{
		System.out.println(pro.productId());
		System.out.println();	}
}
/*
class ProductComparator implements Comparator<Product>{

	TreeSet<Product> products =new TreeSet();
	
	public int compare(Pro--++++++duct o1, Product o2) {
		// TODO Auto-generated method stub
//		return 0;
		
		System.out.println("comparing"+ ":"+o1.productName()+"with" +":" +" "+o2.productName());
		int diff = o1.productName().compareTo(o2.productName());
		
		if(diff != 0)
			return diff;
		else{
			diff = (int) (o1.productPrice() - o2.productPrice());
			System.out.println("comparing"+o1.productPrice()+"with" +o2.productPrice());
			return diff;
		}
*/
}
//}