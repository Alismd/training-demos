

public class Product implements Comparable {
	private int id;
	private String name;
	private double price;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int id, String name, double price) {
		
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public int productId()
	{
		return id;
	}
	public String productName()
	{
		return name;
	}
	public double productPrice()
	{
		return price;
	}
@Override
	public int compareTo(Object o) {
		System.out.println("comparing" +this.productId() + ";"  + "with" +((Product) o).productId());
		
		int diff = (int) (this.id- ((Product)o).id);
		return diff;
		
	}
	
	@Override
	public String toString() {
		
		return id+  ":" +name+ ":" +price;
	}
	
}

