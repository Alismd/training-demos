
public class Entry {
public static void main(String[] args)
{
	
	Person person1=new Person("ali",20);

	
	Person person2=new Person("preethi",22);
	//Comparable c =new Comparable;
	//Person person3=new Person("preethi",22);
	//person1.equals("ali");
	

	if(person1.equals("preethi"))
	{     
    System.out.println("Username is same");
	}
	else
     {
      System.out.println("not same");
     } 
}
}
