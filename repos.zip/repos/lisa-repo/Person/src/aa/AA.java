package aa;
import ali.A;
public class AA extends A {
public static void main(String[] args) {
	System.out.println("rd");
	A a=new A();
	a.main(args);
	System.out.println(a); 
	
}
}
