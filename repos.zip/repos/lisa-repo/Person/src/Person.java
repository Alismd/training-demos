

public class Person {
private String userName;
private int age;
public Person(String userName,int age)
{
	this.userName=userName;
	this.age=age;
}
@Override
/*	public boolean equals(Object obj) 
   {
	if(this.userName.equals(((Person)obj).userName))
	
	{
	return true;
	}
	return false;
*/
	public boolean equals(Object obj) {
		if (!(obj instanceof Person))
			return false;
		
		return this.userName.equals(((Person)obj).userName);
  
}}
