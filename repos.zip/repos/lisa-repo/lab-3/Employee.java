
public class Employee 
{public static void
	 main(String [] args)
	{
	    Date joiningDate = new Date(24, 10, 1997);
		Employee1 e1 = new Employee1("ali", "smd",45464, "ada3",joiningDate); 
		Employee1 e2 = new Employee1("preethi", "R",2342378, "a4",joiningDate); 
		e1.display();
		
	    System.out.println("");
		e2.display();
		}
}
