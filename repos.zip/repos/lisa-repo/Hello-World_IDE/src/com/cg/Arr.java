package com.cg;

import java.util.Arrays;

public class Arr {
public static void main(String[] args) {
	int mat[][]  =new int[10][10];
	//a[0]=20;
   //a[1]=20;a[2]=20;a[3]=20;a[4]=20;a[5]=20;a[6]=20;a[7]=20;
	mat[0][0]=10;
	mat[0][1]=10;
	mat[1][0]=10;
	mat[1][1]=10;
	for (int row=0;row<mat.length;row++)
		
	
    for(int col=0;col<mat[row].length;col++)
    {
			
			System.out.println(mat[row][col]);	
	}
}
}
                                   
