package wallet;

public class Account {
private long accountNumber;
private Customer customer;
private double balance;
public void setAccountNumber(long accountNumber)
{
	this.accountNumber=accountNumber;
}
public long getAccountNumber()
{
	return accountNumber;
}
public void setBalance(double balance)
{
	this.balance=balance;
}
public double getBalance()
{
	return balance;
}
public void setCustomer(Customer customer)
{
	this.customer=customer;
}
public Customer getCustomer()
{
	return customer;
}
	

}
