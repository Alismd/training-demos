package wallet;

public class Services
{
public static int id;

public Account createAccount(String name,double balance)
{
	id++;
	Account a=new Account();
	a.setAccountNumber(id);
	Customer c=new Customer();
	c.setName(name);
	a.setCustomer(c);
	a.setBalance(balance);
	return a;
}
public Account showBalance()
{
	Account a =new Account();
}
}
