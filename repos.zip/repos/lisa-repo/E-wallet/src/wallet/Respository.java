package wallet;

public class Respository {
Account[] accounts=new Account[5];
}
