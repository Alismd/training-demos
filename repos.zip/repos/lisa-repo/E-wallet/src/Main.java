
public class Main {
public static void main(String[] args) {
	Customer c=new Customer();
	Account a=new Account();
	c.setName("Ali");
	a.getAccount_Number();
	a.setCustomer(c);
	a.setAmount(738436);
	System.out.println(a.getAccount_Number());
	System.out.println(c.getName());
	System.out.println(a.getAmount());
	

	c.setName("preethi");
	a.getAccount_Number();
	a.setCustomer(c);
	a.setAmount(766);
	System.out.println(a.getAccount_Number());
	System.out.println(c.getName());
	System.out.println(a.getAmount());
	
}
}
