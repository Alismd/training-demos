
public class Account {
private int Account_Number;
private double amount;
private Customer customer;
static int count=1111111;
public int getNo()
{
	return Account_Number;
}
public Account()
{
	this.Account_Number=Account_Number;
	Account_Number=count;
	count++;
}
public int getAccount_Number()
{
	return Account_Number;
}
//public void setAccount_Number(int Account_Number)
//{
	
//}
public void setAmount(double amount)
{
	this.amount=amount;
}
public double getAmount()
{
	return amount;
}
public void setCustomer(Customer c)
{
	this.customer=c;
}
public Customer getcustomer()
{
return customer;
}

}
