
public class Entry {
public static void main(String[] args) {

	Node node1=new Node(100,null);
	
	System.out.println(node1.toString());
	
	
	
	
	
	
	//	LinkedList list1 = new LinkedList();
//	list1.head  = new Node(1);
//	Node second = new Node(2);
//	Node third  = new Node(3);
//	list1.head.next=second;
//	second.next=third;
	
}


}

