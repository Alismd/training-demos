import java.util.Collection;
class A {
 //static final int SIZE=2*1024*1024*1024;
  
	public static void main(String[] args) {
  //  int[] i = new int[SIZE];
     short[] i =new short[Short.MAX_VALUE];
     short[] j=new short[Short.MAX_VALUE];
     short[] k=new short[Short.MAX_VALUE];
     short[] l=new short[Short.MAX_VALUE];
 		System.out.println("al");
   }
}
