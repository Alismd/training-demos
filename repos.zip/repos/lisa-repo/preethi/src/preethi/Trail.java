package preethi;

public class Trail {
 static int id=10;
	int a;
private int number;
Trail()
{
	this.id=id;
	
	a=id++;
	
}
public void display()
{
 System.out.print(a);
}
public void setNumber(int number)
{
	this.number=number;
}
public int getNumber()
{
	return number;
	
}

}
