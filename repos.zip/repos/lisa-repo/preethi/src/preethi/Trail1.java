package preethi;

public class Trail1{


public static void main(String[] args) {
	Trail t=new Trail();
	Trail t1=new Trail();
	Trail t2=new Trail();
//	Trail t1=new Trail(40);
	//System.out.println(id);
	t.setNumber(100);
	int c =t.getNumber();
	t1.setNumber(200);
	int d=t1.getNumber();
	System.out.println(c);
	System.out.println(d);
//	String b=t.ide();
	t.display();
	t1.display();
	t2.display();		}
}
