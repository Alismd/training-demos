package preethi;

public class Entry{
	public static void main(String[] args) {
		Person p1 =new Person("preethi",18);
		Person p2 =new Person("preethi",20);
	
	if (p1.equals(p2));{
	{
		System.out.println("hi");
		
	}
	else	
	{
		System.out.println("hello");
	}}
}}