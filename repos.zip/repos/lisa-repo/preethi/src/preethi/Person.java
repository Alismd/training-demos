package preethi;
public class Person
{
private String name;
private int age;
public Person(String name,int age)
{
	this.name=name;
	this.age=age;
}
@Override
	public boolean equals(Object obj) {
	if(this.name.equals(((Person)obj).name))
	{
		return true;
	}
	return false;
	}

}