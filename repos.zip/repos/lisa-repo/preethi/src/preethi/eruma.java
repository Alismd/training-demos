package preethi;

public class eruma 
{
     public static void main(String [] args)
 {
      System.out.println("hi this is preethi");
 }   
}
