
public class LinkedList {
	
private Node head;
 class Node{
	 
 }


public boolean add(int data)
{
	return true; 
}
public void display()
{
	
}
}
