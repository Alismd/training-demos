
public class B {
	 // private  char a;.
	 //private static 
		public static void main(String[] args) {
			
			     m1();
		
			//char[] ch1 = new char[200000000];
			//char ch =  '\uFFFF';
			//		System.out.println((double)ch);
		//	System.out.println(Integer.MAX_VALUE);
		//	System.out.println(Character.MAX_CODE_POINT);
		 //	System.out.println(Double.MAX_VALUE);
	     //	System.out.println(Integer.bitCount(2));
		//	int a;
	    // 	a=201*565*874*444;
		//	System.out.println((long)a);
			System.out.println("inside main");
				}
		//System.out.println("A");
		public static void m1()
		{
			try
			{
				int i=0;
			
			for (i=0;i<10;i++)
			
				m1();
			System.out.println("A");
			}catch(Exception e)
			{
				System.out.println("asdasd");
			}
			
			}
		}


