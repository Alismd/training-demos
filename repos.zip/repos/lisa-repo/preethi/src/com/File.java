package com;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class File  {
	
	FileInputStream file1;
public void readFile1()
{
	
	
	String fileName = "Employee.txt";
	{
	
		try {
			file1 = new FileInputStream(fileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		while(true){
			int b;
			try {
				b = file1.read();
				if(b == -1)
					break;
				System.out.print((char)b);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			//}	
		//	catch(Exception e){
			//	System.out.println(e.getMessage());
			}	
			
}}
}}