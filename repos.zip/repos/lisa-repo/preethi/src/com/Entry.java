package com;

public class Entry {
public static void main(String[] args) {
	File f1=new File();
	Thread t1=new Thread1(f1);
	t1.start();
}

}
class Thread1 extends Thread
{
	private File f1;

	public Thread1(File f1) {
		this.f1 = f1;
	} 
@Override
public void run() {
	// TODO Auto-generated method stub
	}

}