
public class Bank {
public static void main(String[] args) {
  
	Account a =new Account(23245);
	Account a1=new Account(45487);
  
	Customer c=new Customer();
    c.setName("ali");
    a.setCustomer(c);
    Customer c1=new Customer();
    c1.setName("preethi");
    a1.setCustomer(c1);
    Account a3 =new Account(12345);
    Customer c3=new Customer();
    c3.setName("arthi");
    a3.setCustomer(c3);
System.out.println(a.getCustomer().getName());
System.out.println(a.getAccount());
System.out.println(a.getBalance());

System.out.println(a1.getCustomer().getName());
System.out.println(a1.getAccount());
System.out.println(a1.getBalance());


System.out.println(a3.getCustomer().getName());
System.out.println(a3.getAccount());
System.out.println(a3.getBalance());

}


}
