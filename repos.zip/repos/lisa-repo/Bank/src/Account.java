
public class Account {
private int id;
private double balance;
public static int count=1001;
private Customer customer;

public Account(double balance)
{
	this.id=id;
	this.balance=balance;
	//count=1001;
	count++;
	id=count;
	
}

public void setCustomer(Customer customer)
{
	this.customer=customer;
}

public Customer getCustomer()
{
	return customer;
}
public double getBalance()
{
	return balance;
}
public int getAccount()
{
	return id;
}
//public Account getAccount()
//{
	//System.out.println("name:"+getCustomer());
//	System.out.println("account number and balance:"+id+balance);
	
//}

/*public String toString()
{
	//return "name:"+ getCustomer()+"Account number"+id;
	return getCustomer();
}*/


}
