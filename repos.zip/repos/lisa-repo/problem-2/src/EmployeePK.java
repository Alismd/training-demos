
public class EmployeePK {
	private int id;
	private String entity;
	public EmployeePK(int id, String entity) {
		this.id = id;
		this.entity = entity;
	}
public int getId() {
	return id;
}
public String getEntity() {
	return entity;
}
}
