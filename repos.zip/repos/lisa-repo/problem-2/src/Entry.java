import java.util.HashMap;

public class Entry {
public static void main(String[] args) {
	Emplojyee e1=new Employee(1001,"Ali","a457","sales");
	Employee e2=new Employee(1001,"Ali","a457","sales");
	
	EmployeePK pk=new EmployeePK(1001,"a457");
	EmployeePK pk1=new EmployeePK(1001,"a457");
	
	HashMap<EmployeePK,Employee> entries;
	entries = new HashMap<>();
	entries.put(pk, e1);
	entries.put(pk1, e2);
	System.out.println(entries.size());
	  System.out.println(entries.get(pk1));
	 

}
}
