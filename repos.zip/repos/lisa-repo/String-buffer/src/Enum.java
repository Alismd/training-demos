
public class Enum {

}
