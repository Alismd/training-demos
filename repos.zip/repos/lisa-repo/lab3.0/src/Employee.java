
public class Employee {
    private int empId;
    private String name;
    private Date joiningDate;
    private double salary;
    private static int count=12345;
public Employee(int  empId, String name,Date joiningDate,double salary)
{
	this.name=name;
	this.joiningDate=joiningDate;
	this.salary=salary;
	this.empId=empId;
	empId=count++;
}
public double getSalary()
{
	return salary;
}
}
