
public class PermanentEmployee extends Employee
{
private static int count;

PermanentEmployee(String name,Date joiningDate,double Salary)
{
	super(empId, name, joiningDate, Salary);
}
public double getSalary()
{
	return super.getSalary();
}

}
