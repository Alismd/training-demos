
public class Contractor 
{
private String name;
private double rate;
ContractEmployee[] contractEmployees;

public void setRate(double rate)
{
	this.rate=rate;
}}