

public class Contractor {
	private String name;
	public static int rate;
	
	
	
	public Contractor(String name, int rate){
		this.name=name;
		this.rate=rate;
	}
	
	

	public Contractor() {

		// TODO Auto-generated constructor stub
	}



	public void setName(String name){
		this.name=name;
	
		}
	public String getName(){
		return name;
	}
	public void setRate(int rate){
		this.rate=rate;
		
	}
	
}
