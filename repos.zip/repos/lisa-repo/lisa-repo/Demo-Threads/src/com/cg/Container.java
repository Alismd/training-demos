package com.cg;

public class Container {

	private String message;
    private boolean isMessageAvailable;
	
	synchronized
	public void put(String message) throws InterruptedException{
		while(isMessageAvailable== true){
			((Container) this).wait();
		}
		
		Thread.sleep(100);
		this.message = message;
		System.out.println("PUT");
		
		isMessageAvailable = true;
		
		((Container) this).notify();
		//Container container2=new Container();
		
	}
	
    synchronized
	public String get() throws InterruptedException{
		while(isMessageAvailable == false){
			((Container) this).wait();
		}
		
		Thread.sleep(100);
		
		System.out.println("GET");

		isMessageAvailable = false;
		((Container) this).notify();
		//message.notify();
		
		return message;
	}
	
	
	
	
}
