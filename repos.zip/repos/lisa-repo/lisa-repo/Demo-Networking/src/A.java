import org.jcp.xml.dsig.internal.dom.ApacheData;

import com.sun.org.apache.xml.internal.security.signature.XMLSignatureInput;

public class A implements ApacheData {
	@Override
	public XMLSignatureInput getXMLSignatureInput() {
		// TODO Auto-generated method stub
		return null;
	}

}
