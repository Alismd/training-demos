import java.util.*;  
public class Employeecap 
{  
    int  i;
 	int id;
 	static int count=12160;
	static int  list=0;
    String first_name;
   	String last_name;
    String grade;  
    double   salary;

    
       public void accept()  
        {  
              Scanner s= new Scanner(System.in); 
              System.out.println("\n\tWelcome to Employee Creation System\n");
			  
              System.out.println("Enter first Name of Employee:\n");  
              first_name=s.nextLine();
  
              System.out.println("Enter last Name of Employee:\n");  
              last_name=s.nextLine();
 
              System.out.println("Enter the grade of Employee:\n");  
              grade=s.nextLine(); 
 
             System.out.println("Enter the Salary:\n");  
             salary=s.nextDouble();
 
        }  
   
     public void print()  
         {  
    	   
    	       		System.out.println("\t\tEmployee Details\t");
					System.out.println("");
					System.out.println("\tEmployee id is \t:\t"+id); 
            		System.out.println("\tName of Employee is \t:\t"+first_name  +last_name); 
					// System.out.println(\t"Name of Employee:\t"+last_name); 
            		System.out.println("\tSalary of Employee\t:\t"+salary);  
            		System.out.println("\tgrade of Employee\t:\t"+grade);  
        //    		System.out.println("\tjoining date is \t:\t"+doj);
					System.out.println("\tTotal number of employees added \t:\t"+list);
         }  
}
            	
   