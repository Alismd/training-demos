
public class Employees {
	   public static void main(String[] args) 
	    {  
		   
	           Employeecap emp = new Employeecap(); 
	           for(int i=1;i<5;i++)
	    {
	      	  
	       	   emp.accept();  
	           emp.print();
	    }  
	       	   {
				   
			   }
	                       
	    }
	  
}

