
public class A {
		  static void m1(String s) {
		    s = s.trim(); s = s.concat("D");
		  }
		  public static void main(String[] s) {
		    String s1 = "A", s2 = " B ", s3 = "C";
		    m1(s1);
		    System.out.print(s1 + s2 + s3);
		}}


