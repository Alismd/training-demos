import java.util.HashMap;
import java.lang.String;
public class Entry7 {
	public static void main(String[] args) {
		
		HashMap<Long, String> entries;
		
		entries = new HashMap<>();
		
//		byte b = 127;
		
		entries.put(9890012345L,"AirTel");
		System.out.println("added");
		
		//entries.put(null,"JIO");
		//entries.put(null,"JIO");
		
		String oldValue = entries.put(9822098220L,"Idea");
		System.out.println(oldValue);
		oldValue = entries.put(9822098220L,"Vodafone");
	System.out.println(oldValue);
		entries.put(8807330373L, "jio");
	//	oldValue = entries.put(8807330373L,"docomo");
	//System.out.println(oldValue);
		System.out.println("added");
		
		
		
		System.out.println(entries.size());
		
		
		
	}
}
