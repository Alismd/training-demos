import com.cg.*;
import com.cg.Dog;
import com.cg.Pet;
import com.cg.Safe;

public class Entry2 {

	public static void main(String[] args) {
		//Pet petRef;
		Animal d;
		d=new Dog();
		
		d.eat();
		
//		petRef = new Pet();
		
	//	petRef = new Dog();// need to define the class in which the interface has been implemented
		
	//	System.out.println(petRef.beFriendly());;
	//	petRef.play();
		
	//	Animal animalRef=null;
		
	//	petRef = (Pet)animalRef;
		
	//	String message = new String();
		
//		petRef = (Pet)message;
//		System.out.println(petRef.MAX);
//		System.out.println(Pet.MAX);
		Safe saferef;
		saferef = new Dog();
		System.out.println(saferef.beFriendly());;
		saferef.play();
		System.out.println(saferef.MAX);
		System.out.println( saferef.roamStreets());
		System.out.println(saferef.cost());
	}
	
	
	
}
