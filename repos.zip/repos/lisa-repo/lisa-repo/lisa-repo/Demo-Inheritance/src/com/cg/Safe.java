package com.cg;

public interface Safe extends Pet
{
  public boolean roamStreets();
  
  public int cost();
 int cst=500;
	  
  
}
