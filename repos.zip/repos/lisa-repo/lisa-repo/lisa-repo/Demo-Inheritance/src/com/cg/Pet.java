package com.cg;

public interface Pet {
//	public Pet(){
		
//	}
	
	
 public boolean beFriendly();

	
 
	public   void play();
	
	 int MAX=88;

	
	
	
	
	
}
