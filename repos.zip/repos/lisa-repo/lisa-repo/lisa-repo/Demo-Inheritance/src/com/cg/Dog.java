package com.cg;

public  class Dog extends Canine implements Safe{
	@Override
	
	public void eat() {
	System.out.println("I love biscuits");
	}
	
	@Override
	public boolean beFriendly() {
		// TODO Auto-generated method stub
		return true;
	}
	public void roam() {
		
		System.out.println("I love ");
	}
	
	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("You can play with me");
	}
	@Override
	public boolean roamStreets() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public int cost() {
		// TODO Auto-generated method stub
		return cst;
	}
}
