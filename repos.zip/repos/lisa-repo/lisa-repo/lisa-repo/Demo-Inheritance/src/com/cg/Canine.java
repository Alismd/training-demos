package com.cg;

public class Canine extends Animal{
	public Canine() {
		super("Grey", 1);
	}
	
	@Override
	public void roam() {
		System.out.println("I roam in a group");
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
