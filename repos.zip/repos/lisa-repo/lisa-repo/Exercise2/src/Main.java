
public class Main {
public static void main(String[] args) {
	Player p =new Player();
	Game g = new Game();
	
	Game[] games;
	games=new Game[5];
  
	
	Player[] players;
    players=new Player[5];
	
   // int  i=0;
	//for (i=0;i<players.length;i++)
    	players[0]=new Player();
        players[0].setName("Ali");
        players[1]=new Player();
	    players[1].setName("Preethi");
	    players[2]=new Player();
	    players[2].setName("Arthi");
	    players[3]=new Player();
	    players[3].setName("bindhu");
	    players[4]=new Player();
	    players[4].setName("praba");
//	for (i=0;i<games.length;i++)
	    games[0]=new Game();
		games[0].setGame("football");
		games[1]=new Game();
		games[1].setGame("cricket");
		games[2]=new Game();
		games[2].setGame("tennis");
		games[3]=new Game();
		games[3].setGame("Badmiton");
		games[4]=new Game();
		games[4].setGame("Hockey");
	
	System.out.println("name:" +players[0].getName());
	System.out.println("games:"+games[0].getGame() +"\t" +games[2].getGame());
	System.out.println("----------------------------------------");
	System.out.println("name:" +players[1].getName());
	System.out.println("games:"+games[0].getGame() +"\t" +games[3].getGame());
	System.out.println("----------------------------------------");
	System.out.println("name:" +players[2].getName());
	System.out.println("games:" +games[2].getGame() +"\t"+games[0].getGame());
	System.out.println("----------------------------------------");
	System.out.println("name:" +players[3].getName());
	System.out.println("games:" +games[3].getGame() +"\t"+games[4].getGame());
	System.out.println("----------------------------------------");
	System.out.println("name:" +players[4].getName());
	System.out.println("games:" +games[2].getGame() +"\t"+games[3].getGame());
	
	
}
}
