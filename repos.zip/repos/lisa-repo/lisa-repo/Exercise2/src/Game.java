
public class Game {
	
private String name;

public void setGame(String name)
{
	this.name=name;
}

public String getGame()
{
	return name;
}
}
