package com;

public class Game1 {
	private String gamename;

	public String getGamename() {
		return gamename;
	}

	public void setGamename(String gamename) {
		this.gamename = gamename;
	}


}
