package com;

public class Player1 {
	private String name;
	private Game1 gamename;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getGamename() {
		return name;
	}

	public void setGamename(Game1 gamename) {
		this.gamename = gamename;
	}



}
