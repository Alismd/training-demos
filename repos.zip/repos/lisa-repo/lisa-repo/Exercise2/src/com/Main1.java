package com;

public class Main1 {
	public static void main(String [] args){   
		Player1[] player;
		player=new Player1[2];
		Game1[] games;
		games=new Game1[2];
		player[0]=new Player1();
		player[0].setName("ali");
		player[1]=new Player1();
		player[1].setName("preethi");
		
		games[0]=new Game1();
		games[0].setGamename("cricket");
		
		games[1]=new Game1();
		games[1].setGamename("basketball");
		System.out.println("name:"+player[0].getName());
		System.out.println("name:"+player[1].getName());
		System.out.println("games:"+games[1]+"\t" +games[0].getGamename());
		System.out.println("games:"+games[0]+"\t" +games[1].getGamename());
	}

}
