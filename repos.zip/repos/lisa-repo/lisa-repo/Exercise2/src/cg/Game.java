package cg;

public class Game {
private String name;


public void setGameName(String name)
{
	this.name=name;
}
public String getGameName()
{
	return name;
}
	
}
