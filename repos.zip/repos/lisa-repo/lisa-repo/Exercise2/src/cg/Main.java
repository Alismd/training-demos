package cg;

public class Main {
public static void main(String[] args) {
	
	//Game g = new Game();
	Player p = new Player();
    	p.setName("Ali");
	  Game[] game = new Game[5];
	  
	  for (int i=0;i<game.length;i++)
	    
	  game[i]=new Game();  
	  game[0].setGameName("Foot Ball");
	  game[1].setGameName("Cricket");
	  game[2].setGameName("Volley ball");
	  game[3].setGameName("Basket ball");
	  game[4].setGameName("Rugby");
	  
///////public Game//////////////////////////////////	 
		  
	  p.setGame(game); 
	  System.out.println("player is\t" +p.getName());
      p.setName("preethi");
      System.out.println("player is\t" +p.getName());
	  System.out.println("plays the games:\t"+p.getGame().toString());
}
}

