
public class Address {
	private String line;
	private Country country;
	public void setLine(String line)
	{
		this.line=line;
	}
	public String getLine()
	{
		return line;
		
	}
	public void setCountry(Country co)
	{
		this.country=co;
	}
	public Country getCountry()
	{
		return country;			
	}
	

}
