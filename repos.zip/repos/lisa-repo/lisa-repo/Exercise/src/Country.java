
public class Country {
private String name;
private City city;

public void setCountry(String name)
{
	this.name=name;
}
public String getCountry()
{
return name;
}
     
public void setCity(City c)
{
	this.city=c;
}
public City getCity()
{
	return city;
}

}
