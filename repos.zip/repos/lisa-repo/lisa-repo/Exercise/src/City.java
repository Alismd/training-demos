
public class City {
private String name;
public void setCity(String name)
{
	this.name=name;
}
public String getCity()
{
	return name;
}
}
