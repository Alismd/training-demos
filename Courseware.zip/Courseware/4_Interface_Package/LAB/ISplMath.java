package cg.javaflp.practice;

/**
 * This interface extends IMath interface
 */
public interface ISplMath extends IMath {
	
	public double sqrt(double number);
}
