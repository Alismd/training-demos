package tdi.javaFLP.languageBasic;

public class Cls1 {

	/** Main method - stating point of program
	 * @param args 
	 */
	public static void main(String[] args) {

		// instantiating object of Cls2
		Cls2 cls2Obj = new Cls2();
		
		// calling display method of Cls2
		cls2Obj.display();
	}
}
