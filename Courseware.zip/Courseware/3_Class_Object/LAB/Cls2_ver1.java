package tdi.javaFLP.languageBasic;

/**
 * This class have a method "display"
 * which displays a message on console
 */
public class Cls2 {
	
	/** ignore what is public, void here
	 *  that we will learn when we will see
	 *  the method signature in details
	 */
	
	/* Since this method is only use 
	 * to display a message on console
	 * thus have no return type 
	 */
	public void display(){
		System.out.println("Hi.... You are in display mehtod of cls2");
	}
}
