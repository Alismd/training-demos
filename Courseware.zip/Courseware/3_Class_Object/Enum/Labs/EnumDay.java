package cg.javaflp.practice;

public enum EnumDay {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
	
	public void display(){
		System.out.println("MUAHAHAHAHAH....");
	}
}
