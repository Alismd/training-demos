package tdi.javaFLP.languageBasic;

public class LoopPractice1 {
	
	public static void main(String[] args) {
		
		int x = 3;
		System.out.println("Table of : " + x);
		
		for(int i = 1; i < 11; i++){
			System.out.println(x + " * " + i + " : " + x * i);
		}
	}
}
