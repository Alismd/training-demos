public class MathPrac {

	static double j;
	static double i;

	public static void main(String [] args){
		//System.out.println("package2 in class2");
	
	//while (i<10){
		//System.out.println(" let us play ");
		//i++;
		//for(i=0;i<10;i++){
			//j =Math.floor(Math.random()*10);
		//j=Math.abs(-6.8);
		//j=Math.floor(7.2);
		//j=Math.ceil(7.2);
	        //j=Math.sin(30);
	        //j=Math.max(45.889, 45.887);
		//j=Math.min(45.889, 45.887);
		//j=Math.exp(1);
		//j=Math.pow(2,3);
		//j=Math.toRadians(30);
		//j=Math.toDegrees(0.52);
		//j=Math.sin(30);
		//j=Math.cos(30);
		//j=Math.tan(30);
		//j=Math.sqrt(25);
		//j=Math.log(100);
		//j=Math.round(32.5);
		//i=Math.rint(32.5);
		//i=Math.asin(0.866);
		//i=Math.toDegrees(1.0471467458630677);
		  i=Math.toRadians(59.997089068811974);
		//j=Math.IEEEremainder(25, 4);
		    //System.out.println(j);
		    System.out.println(i);
		
		
	}
	
		
		
	
}
	

