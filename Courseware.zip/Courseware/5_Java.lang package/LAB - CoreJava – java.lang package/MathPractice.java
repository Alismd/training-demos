package cg.javaflp.practice;

/**
 * This class is use to practice various methods of 
 * MATH class
 */
public class MathPractice {

	public static void main(String[] args) {
		
		System.out.println(Math.abs(44.5));
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println(Math.pow(3, 4));
		System.out.println(Math.sqrt(55));
		System.out.println(Math.floor(-55.8));
		System.out.println(Math.nextUp(55));
		System.out.println(Math.tan(45));
		System.out.println(Math.toDegrees(Math.tan(45)));
	}
}
